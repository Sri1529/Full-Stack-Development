package Assesment_1;
import java.util.*;
public class Sherlock {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		//System.out.println("Enter the number of apple:");
		//int a=sc.nextInt();
		//System.out.println("Enter the number of people:");
		//int b=sc.nextInt();
		int a=6,b=2;
		if(a%b==0)
		{
			System.out.println("1");
		}
		else
		{
			System.out.println("0");
		}
		

	}

}
