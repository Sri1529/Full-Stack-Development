package Assesment_1;

public class Simple_Sum {

	public static void main(String[] args) {
		int a=9,b=3,c=7;
		
System.out.println(a+b+c);

	}

}
