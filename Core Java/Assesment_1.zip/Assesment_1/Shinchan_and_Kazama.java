package Assesment_1;

public class Shinchan_and_Kazama {

	public static void main(String[] args) {
		int a=5,b=2,speed=3;
		int distance =a-b;
		
		int time=distance/speed;
        System.out.println(time);
	}

}
