package Assesment_1;

public class Penny_and_Charity {

	public static void main(String[] args) {
		int ppl=4;
		int clth=30;
		
		
		if(clth>ppl)
		{
		int div=clth/ppl;
	  System.out.println(div);
		}
		else
		{
			System.out.println("-1");
		}
		
	}

}
