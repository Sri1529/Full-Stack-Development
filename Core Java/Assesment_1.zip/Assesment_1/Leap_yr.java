package Assesment_1;

public class Leap_yr {

	public static void main(String[] args) {
		int yr=2003;
		
		if(yr%4==0)
		{
         System.out.println("Yes");
		}
		
		else
		{
			System.out.println("No");
		}
	}

}
