package Assesment_1;

public class Pokemon_Master {

	public static void main(String[] args) {
		int a=4;
		int b=6;
		if(a/b==0)
		{
           System.out.println("0");
		}
		
		else
		{
			System.out.println("1");
		}

	}

}
