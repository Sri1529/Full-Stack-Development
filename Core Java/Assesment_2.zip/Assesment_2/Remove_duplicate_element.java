package Assesment_2;

public class Remove_duplicate_element {

	public static void main(String[] args) {
		int arr[]= {1,2,3,3,3,4};
		
		int dup=0;
        
        for(int j=arr[0];j<arr.length;j++)
        {
        	
        for(int i=0;i<arr.length;i++)
        {
        	if(arr[j]==arr[i])
        	{
        		dup=arr[i];
        	}
        	
        	
        }
        
        }
        
        System.out.println(dup);
		
		
	}

}
