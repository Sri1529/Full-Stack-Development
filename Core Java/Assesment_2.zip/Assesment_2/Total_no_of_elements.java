package Assesment_2;

public class Total_no_of_elements {

	public static void main(String[] args) {
		
		int arr[]= {12,55,8,90,7};
		
		System.out.println("The total elements in array are:"+arr.length);
		
		
				

	}

}
