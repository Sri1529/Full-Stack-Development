package Assesment_3;
import java.util.*;
public class Move_all_zero_to_front {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the size of the array:");
		int n=sc.nextInt();
		int temp=0;
		int arr[]=new int [n];
		
		for(int i=0;i<n;i++)
		{
			arr[i]=sc.nextInt();
		}
		System.out.println("The given elements are:");
		for(int i=0;i<n;i++)
		{
			System.out.print(arr[i]+" ");
		}
		System.out.println();
		for(int i=0;i<n;i++)
		{
			for(int j=i+1;j<n;j++)
			{
			if(arr[i]==0)
			{
			  
				arr[i-1]=arr[i];
				arr[i]
				
				
			}
			}
		}
		System.out.println("After moving the zeros to front:");
		for(int i=0;i<n;i++)
		{
			System.out.print(arr[i]+" ");
		}
		
			

	}

}
