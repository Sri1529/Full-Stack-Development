package Assesment_3;
import java.util.*;
public class Sum_and_Product_of_Elements_in_a_RowColumn {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int sum=0,product=1;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the no of rows:");
		int r=sc.nextInt();
		System.out.println("Enter the no of columns:");
		int c=sc.nextInt();
		
		int arr[][]=new int[r][c];
		
		for(int i=0;i<r;i++)
		{
		for(int j=0;j<c;j++)
		{
			arr[i][j]=sc.nextInt();
		}
		}
		
		System.out.println("The given matrix is:");
		for(int i=0;i<r;i++)
		{
			for(int j=0;j<c;j++)
			{
				System.out.print(arr[i][j]+" ");
			}
			System.out.println();
		}
		System.out.println("Sum product:");
	
		int i=0;
			for(int j=0;j<c;j++)
			{
				if(j>c-1)
				{
					i++;
				}
				sum=sum+arr[i][j];
				}
			for(int j=0;j<r;j++)
			{
				System.out.println("Sum of row "+i+1+":"+sum);
			}
			
		
		
		

	}

}
